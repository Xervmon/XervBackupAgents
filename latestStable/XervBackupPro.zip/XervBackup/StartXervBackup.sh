#!/bin/bash

export LD_LIBRARY_PATH=`pwd`
mono XervBackup.exe