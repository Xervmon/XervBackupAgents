If XervBackup complains about the version of SQLite being too old,
use the StartXervBackup.sh script to launch XervBackup with the bundled
SQLite library.

The StartXervBackup.sh script can be made executable with this command:
chmod +x StartXervBackup.sh